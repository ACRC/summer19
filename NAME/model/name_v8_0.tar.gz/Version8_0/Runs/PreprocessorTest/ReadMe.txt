Read me file for Tests
Date:   6/11/06
Author: Dave Thomson

Preprocessor test
-----------------

Test.bat - Script for testing code preprocessor on Windows PCs. 

Test.in - test file for code preprocessor.

OldTest.out - old output from test for regression testing.



