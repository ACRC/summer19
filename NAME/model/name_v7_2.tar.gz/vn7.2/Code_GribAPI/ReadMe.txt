Read me file for using ECMWF GRIB-API software with NAME.

Important Note:
--------------

The ECMWF GRIB API software is no longer supplied with the NAME distribution.
Users requiring a copy of the software can download it from the ECMWF website, see

https://software.ecmwf.int/wiki/display/GRIB/Home


Local files for GRIB-API use with NAME: 
--------------------------------------

/local } A folder containing local tables that define parameters specific to the NAME model

LinuxIntelRelease } A local compile script created by us to simplify the GRIB-API compilation process

ReadMe.txt  } This file

Changes.txt } Changes file


Introduction:
------------

NAME can use a local build of the GRIB-API package installed by the user (see further guidance
below on building and installing a local copy of the software) or it can use a pre-installed
version of the libraries that might already be available on your system. We recommend using
a thread-safe version of the GRIB-API, especially if NAME will be run using multiple threads.


Compilation (of GRIB-API):
-------------------------

This step is OPTIONAL if a pre-installed copy of the GRIB-API package using shared object libraries
is already available on your system (though equally it is possible to use a local copy in preference
to any central build).

For convenience, the compile script LinuxIntelRelease is supplied to automate the GRIB-API compilation process.
Source files are compiled into the shared object libraries libgrib_api.so, libgrib_api_f77.so
and libgrib_api_f90.so and then installed, along with appropriate tables and templates, into
a specified folder location. By default this installs the GRIB-API to the /SharedLibraries_Linux
subfolder of the NAME distribution.

See the README supplied with your copy of the ECMWF GRIB-API software for further details on compilation, etc.


Compilation (of NAME):
---------------------

NAME is able to access the GRIB API routines at run time provided that this functionality is requested
when the NAME executable is compiled (e.g., by invoking 'make' with the 'USEGRIBAPI' option set to true).

The standard  Makefile (or build script) for NAME will assume that the GRIB-API software has been installed
in the default location (the /SharedLibraries_Linux subfolder of the NAME distribution). When using a copy
of the GRIB-API in a different location (e.g., a centrally installed version), the Makefile / build script
should be modified accordingly to pick up the correct destination for the include (-I) and library (-L) files.

A NAME executable with support for the GRIB API is identified by the inclusion of "GribAPI" in its filename.


Run-time linking and configuration:
----------------------------------

The following environment variables need to be set to configure the GRIB API at run time:

 - GRIB_DEFINITION_PATH=${GRIB_API_DIR}/share/grib_api/definitions
 - GRIB_SAMPLES_PATH=${GRIB_API_DIR}/share/grib_api/samples
 - GRIB_API_INCLUDE=${GRIB_API_DIR}/include
 - GRIB_API_LIB=${GRIB_API_DIR}/lib

where ${GRIB_API_DIR} is the top-level directory of your GRIB API installation.

The ${GRIB_API_LIB} folder also needs to be included in the 'LD_LIBRARY_PATH' environment variable
to ensure that the NAME executable can access the GRIB API shared object libraries.
