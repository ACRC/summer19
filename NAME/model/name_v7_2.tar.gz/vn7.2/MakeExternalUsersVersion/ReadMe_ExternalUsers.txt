!--------------------------------------------------------------
! File:   ReadMe for optional third-party software used by NAME
!--------------------------------------------------------------

This file provides licensing information and installation instructions for third-party software
distributed with the NAME model.


--------
Overview
--------

The distribution is normally supplied on an installation DVD, although it may also be
made available as a .zip file distribution.

The distribution contains the core NAME package (including source code, executables,
documentation and additional resources), which is owned by the Met Office and protected
under Crown Copyright. Use of the core NAME package is governed by the terms of the
licence agreement provided to the external user by the Met Office. The core NAME package
is supplied in the top-level folder "NAMEIII_v[version number]" where [version number]
is the version number for a particular release of NAME, e.g. 6_1.

In addition to the core NAME package, extra third-party software packages may be supplied
as additional components of the distribution or downloaded separately by the user, with 
separate licensing terms applicable to any such package. Third-party software supplied in 
this manner is isolated in separate top-level folders.


-----------------------------
Third-party software packages
-----------------------------

(A) ECMWF GRIB API (supplied)

The ECMWF GRIB API is an application program interface accessible from C and FORTRAN programs
developed for encoding and decoding WMO FM-92 GRIB edition 1 and edition 2 messages.

The ECMWF GRIB API software is licensed under the GNU Lesser General Public License which
incorporates the terms and conditions of version 3 of the GNU General Public License
(see 'lgpl-3.0.txt' and 'gpl-3.0.txt' in the "Code_GribAPI folder").

Version 1.9.5, downloaded 14/12/2010 (see http://www.ecmwf.int/products/data/software/download/grib_api.html).
Any local code modifications, local tables, etc. are indicated in the changes file
(see 'Changes.txt' in the "Code_GribAPI" folder).

- Source files of the GRIB API distribution are provided in the folder "Code_GribAPI"

- Compiled distribution (including shared object libraries) is available in "SharedLibraries_Linux"

Installation instructions: 

 1. Copy the two folders "Code_GribAPI" and "SharedLibraries_Linux" into the NAME structure
    (i.e. the top level of the "NAMEIII_v[version number]" folder). This is the location from
    which the GRIB API code is expected to be run.

 2. Further information and instructions are then provided in the 'ReadMe.txt' file in "Code_GribAPI".
 
 Note that it is advisable (and might be necessary) to recompile the GRIB API code before
 use on external systems.

(B) NetCDF

This software package provides Fortran application interfaces for accessing netCDF data. 
It depends on the netCDF C library, which must be installed first which in turn depends on
HDF5 and zlib libraries.

The netCDF software is released under the Apache 2.0 Open Source License. The full text of the License 
can be viewed at :

   http:www.apache.org/licenses/LICENSE-2.0.html

Installation instructions (netcdf-4.3.3): 

The usual way of building netCDF requires the HDF5 and zlib libraries. 
Versions required are at least HDF5 1.8.8 and zlib 1.2.5 or later.

HDF5 and zlib packages are available from the netCDF-4 ftp site:

  ftp://ftp.unidata.ucar.edu/pub/netcdf/netcdf-4

Note that for building netCDF, it is not necessary to build the HDF5
Fortran, C++, or Java API's.  Only the HDF5 C library is used.

Build zlib like this:
  ./configure  --prefix=/dir
  make check install

Then you build HDF5, specifying the location of the zlib library:

  ./configure --with-zlib=/dir --prefix=/dir
  make check install

If ``make check'' fails for either zlib or HDF5, the problem must be
resolved before the netCDF-4 installation can continue. For HDF5
problems, see the HDF5 help services:

  http://www.hdfgroup.org/services/support.html

After HDF5 is done, download the netCDF C and FORTRAN libraries from

https://www.unidata.ucar.edu/downloads/netcdf/index.jsp

using the links:
  "The Latest Stable netCDF-C Release, tar.gz form"
  "The Latest Stable netCDF-Fortran Release, tar.gz form"


Build the netCDF C libraries, specifying the location of the HDF5 and zlib 
header files and libraries in the CPPFLAGS and LDFLAGS environment variables.  
For example:

  CPPFLAGS=-I/dir/include LDFLAGS=-L/dir/lib ./configure --prefix=/dir
  make check install

Build the FORTRAN library, specifying (1) the location of the netCDF C header
and libraries in the CPPFLAGS and LDFLAGS environment variables and (2) the 
location of the Fortran compiler command and the Fortran 77 compiler command
which could be the same binary. The Fortran compiler command should be the same 
Fortran binary used to compile NAME.

Note that for shared libraries, you may need to add the install
directory to the LD_LIBRARY_PATH environment variable.

  export LD_LIBRARY_PATH=/dir/lib:$LD_LIBRARY_PATH

  CPPFLAGS=-I/dir/include LDFLAGS=-L/dir/lib F77=/opt/intel/composerxe-2011.4.191/bin/intel64/ifort FC=/opt/intel/composerxe-2011.4.191/bin/intel64/ifort ./configure --prefix=/dir
  make check install

The netCDF utilities/libraries are installed under /dir in subdirectores lib/,
include/, and bin/.

