#!/bin/ksh
# Script to build copy of NAME for external users

ExternalVersionsDirectory=~apdg/NameIII/NameIIIExternalVersions

LibraryDirectory=~apdg/NameIII/NameIIILibrary
  
# -------------------------------------------------------------------
# Subroutine for copying a subdirectory of the current directory to 
# a different location, ignoring all .svn subdirectories
# -------------------------------------------------------------------

cpWithoutSvn() {
  Subdirectory=$1
  Destination=$2
  tar --exclude='.svn' -cf ${Subdirectory}.tar ${Subdirectory}
  tar -C ${Destination} -xf ${Subdirectory}.tar
  rm ${Subdirectory}.tar
}

# -------------------------------------------------------------------
# Print out usage message
# -------------------------------------------------------------------

UsageMessage() {
  echo "Usage:"
  echo "   MakeExternalUsersVersion.sh (extract without source code)"
  echo ""
  echo "   MakeExternalUsersVersion.sh --WithSource (extract with source code)"
  echo ""
  echo " extracts the code to the subdirectory /Version<VersionLabel>"
  echo " or /Version<VersionLabel>_WithSource of"
  echo " ${ExternalVersionsDirectory}"
  echo ""
  exit
}

# -------------------------------------------------------------------

# This script should only be used to generate external-users versions
# of frozen revisions. To use it, comment out the following lines
# and change VersionLabel as appropriate.

echo "ERROR: MakeExternalUsersVersion.sh can only be used for frozen versions,"
echo "see source code for details."

exit

# -------------------------------------------------------------------

VersionLabel=6_5

# Check command line arguments
if [[ $# = 0 ]]
then
  echo "Creating external-users version WITHOUT source code in subdirectory"
  echo "/Version${VersionLabel} of ${ExternalVersionsDirectory}"
  WithSource=false
  OutputDirectory=${ExternalVersionsDirectory}/Version${VersionLabel}
elif [[ $# = 1 ]]
then
  if [[ $1 = --WithSource ]]
  then
    echo "Creating external-users version WITH source code in subdirectory"  
    echo "/Version${VersionLabel}_WithSource of ${ExternalVersionsDirectory}"
    WithSource=true
    OutputDirectory=${ExternalVersionsDirectory}/Version${VersionLabel}_WithSource
  else
    UsageMessage
  fi
else
  UsageMessage
fi

#
# remove previous contents of OutputDirectory
# make new directory if one needed
#

if test -d ${OutputDirectory}
then
  rm -Rf ${OutputDirectory} 
fi
mkdir ${OutputDirectory}
chmod g+rw ${OutputDirectory}

#
# set main NAME directory for this external-users version of NAME
# (note that external third-party software is stored separately to the NAME files)
#

NameVersion="NAMEIII_v${VersionLabel}"
NameDirectory="${OutputDirectory}/${NameVersion}"

#
# create main NAME directory
#

mkdir ${NameDirectory}

#
# change to root directory of current NAME frozen version
#

cd ..

#
# copy third-party code (only when providing NAME source code)
#

if [[ ${WithSource} = true ]]
then
  cpWithoutSvn Code_GribAPI                            ${OutputDirectory}/.
  cpWithoutSvn SharedLibraries_Linux                   ${OutputDirectory}/.
  cp MakeExternalUsersVersion/ReadMe_ExternalUsers.txt ${OutputDirectory}/ReadMe.txt
fi

#
# copy NAME code
#

if [[ ${WithSource} = true ]]
then
  cpWithoutSvn Code_Fortran2Html ${NameDirectory}/.
  cpWithoutSvn Code_Name2Adms    ${NameDirectory}/.
  cpWithoutSvn Code_NameIII      ${NameDirectory}/.
  cpWithoutSvn Code_Preprocessor ${NameDirectory}/.
fi

#
# copy standard NAME distribution
#

cpWithoutSvn Executables_Linux ${NameDirectory}/.
cpWithoutSvn Executables_Win   ${NameDirectory}/.

cpWithoutSvn Resources         ${NameDirectory}/.

cpWithoutSvn Runs              ${NameDirectory}/.

cpWithoutSvn Code_IDLGraphics  ${NameDirectory}/.
cpWithoutSvn Code_Python       ${NameDirectory}/.

cpWithoutSvn User_Guides       ${NameDirectory}/.

cp Changes.txt                 ${NameDirectory}/.
cp Copyright.txt               ${NameDirectory}/.
cp ReadMe.txt                  ${NameDirectory}/.

cp NameIII.dsw                 ${NameDirectory}/.
cp NameIII.sln                 ${NameDirectory}/.

#
# delete unwanted files from copied directories - need to rationalise this?
#

rm    ${NameDirectory}/Executables_Linux/Lincom*.exe
rm    ${NameDirectory}/Executables_Win/Lincom*.exe
rm    ${NameDirectory}/Resources/Met/kincaid*
rm    ${NameDirectory}/Resources/Met/Kincaid*
rm    ${NameDirectory}/Resources/Met/Met*.dat
rm    ${NameDirectory}/Resources/Met/HPA*.met
rm    ${NameDirectory}/Resources/Topog/*
rm -R ${NameDirectory}/Runs/[D,F,H,M,U,W,f,h,i,k,l,r,s]*
rm    ${NameDirectory}/Runs/RM*
rm    ${NameDirectory}/Runs/Tests*
rm -R ${NameDirectory}/Runs/Output/*
rm -R ${NameDirectory}/Runs/Output_SingleSite/*

#
# copy topography files
#

cp    ${LibraryDirectory}/Data/UMTopogData/* ${NameDirectory}/Resources/Topog/.

#
# link to sample UMG_Mk6_PT2 met files held on /project/NAME (used by installation test suite)
#

SampleUMFilesOnProject='/project/NAME/apnm/NAMEIIItesting/met/InstallationTest'

rm -R ${NameDirectory}/User_Guides/Test_Runs/Sample_NWP_Met_Data
ln -s ${SampleUMFilesOnProject} ${NameDirectory}/User_Guides/Test_Runs/Sample_NWP_Met_Data

#
# copy user guide documents
#

cp    ${LibraryDirectory}/Documents/ModelDocs/'md15_6_v2(InstallationGuide).pdf'           ${NameDirectory}/User_Guides/Docs/'InstallationGuide.pdf'
cp    ${LibraryDirectory}/Documents/ModelDocs/'md15_7_v4(UserGuideForNWP).pdf'             ${NameDirectory}/User_Guides/Docs/'UserGuideForNWP.pdf'
cp    ${LibraryDirectory}/Documents/ModelDocs/'md15_8_v3(UserGuide).pdf'                   ${NameDirectory}/User_Guides/Docs/'UserGuide.pdf'

ln -s ${NameDirectory}/ModelDocs/'md2_2_v29(Input).pdf'                                    ${NameDirectory}/User_Guides/Docs/'GuideToNAMEInputs.pdf'

#
# copy model docs
#

mkdir ${NameDirectory}/ModelDocs

cp    ${LibraryDirectory}/Documents/ModelDocs/'md1_1_v1(Puffs).pdf'                        ${NameDirectory}/ModelDocs/'md1_1_v1(Puffs).pdf'
cp    ${LibraryDirectory}/Documents/ModelDocs/'md1_2_v3(DryDeposition).pdf'                ${NameDirectory}/ModelDocs/'md1_2_v3(DryDeposition).pdf'
cp    ${LibraryDirectory}/Documents/ModelDocs/'md1_3_v1(DeepConvection).pdf'               ${NameDirectory}/ModelDocs/'md1_3_v1(DeepConvection).pdf'
cp    ${LibraryDirectory}/Documents/ModelDocs/'md1_4_v1(Eulerian).pdf'                     ${NameDirectory}/ModelDocs/'md1_4_v1(Eulerian).pdf'

cp    ${LibraryDirectory}/Documents/ModelDocs/'md2_1_v2(CodeStructure).pdf'                ${NameDirectory}/ModelDocs/'md2_1_v2(CodeStructure).pdf'
cp    ${LibraryDirectory}/Documents/ModelDocs/'md2_2_v29(Input).pdf'                       ${NameDirectory}/ModelDocs/'md2_2_v29(Input).pdf'
cp    ${LibraryDirectory}/Documents/ModelDocs/'md2_3_v1(Errors).pdf'                       ${NameDirectory}/ModelDocs/'md2_3_v1(Errors).pdf'
cp    ${LibraryDirectory}/Documents/ModelDocs/'md2_4_v2(Output).pdf'                       ${NameDirectory}/ModelDocs/'md2_4_v2(Output).pdf'

cp    ${LibraryDirectory}/Documents/ModelDocs/'md3_1_v1(Coords_Investigation).pdf'         ${NameDirectory}/ModelDocs/'md3_1_v1(Coords_Investigation).pdf'
cp    ${LibraryDirectory}/Documents/ModelDocs/'md3_2_v2(Coords).pdf'                       ${NameDirectory}/ModelDocs/'md3_2_v2(Coords).pdf'
cp    ${LibraryDirectory}/Documents/ModelDocs/'md3_3_v3(Constants).pdf'                    ${NameDirectory}/ModelDocs/'md3_3_v3(Constants).pdf'
cp    ${LibraryDirectory}/Documents/ModelDocs/'md3_4_v1(UnitConversion).pdf'               ${NameDirectory}/ModelDocs/'md3_4_v1(UnitConversion).pdf'

cp    ${LibraryDirectory}/Documents/ModelDocs/'md4_1_v1(Decay_Chain).pdf'                  ${NameDirectory}/ModelDocs/'md4_1_v1(Decay_Chain).pdf'
cp    ${LibraryDirectory}/Documents/ModelDocs/'md4_2_v1(Cloud_Gamma).pdf'                  ${NameDirectory}/ModelDocs/'md4_2_v1(Cloud_Gamma).pdf'

cp    ${LibraryDirectory}/Documents/ModelDocs/'md6_1_v1(Fluctuations).pdf'                 ${NameDirectory}/ModelDocs/'md6_1_v1(Fluctuations).pdf'

#cp    ${LibraryDirectory}/Documents/ModelDocs/'md8_1_v3(Buildings).pdf'                    ${NameDirectory}/ModelDocs/'md8_1_v3(Buildings).pdf'
#cp    ${LibraryDirectory}/Documents/ModelDocs/'md8_2_v2(Buildings_Tests).pdf'              ${NameDirectory}/ModelDocs/'md8_2_v2(Buildings_Tests).pdf'

#cp    ${LibraryDirectory}/Documents/ModelDocs/'md9_1_v1(Lincom).pdf'                       ${NameDirectory}/ModelDocs/'md9_1_v1(Lincom).pdf'

cp    ${LibraryDirectory}/Documents/ModelDocs/'md12_1_v1(Radar_Rainfall).pdf'              ${NameDirectory}/ModelDocs/'md12_1_v1(Radar_Rainfall).pdf'

cp    ${LibraryDirectory}/Documents/ModelDocs/'md13_1_v2(Validation_Kincaid).pdf'          ${NameDirectory}/ModelDocs/'md13_1_v2(Validation_Kincaid).pdf'
cp    ${LibraryDirectory}/Documents/ModelDocs/'md13_2_v1(Validation_Etna).pdf'             ${NameDirectory}/ModelDocs/'md13_2_v1(Validation_Etna).pdf'
cp    ${LibraryDirectory}/Documents/ModelDocs/'md13_3_v1(Validation_Hekla).pdf'            ${NameDirectory}/ModelDocs/'md13_3_v1(Validation_Hekla).pdf'
cp    ${LibraryDirectory}/Documents/ModelDocs/'md13_4_v1(Validation_BasicTests).pdf'       ${NameDirectory}/ModelDocs/'md13_4_v1(Validation_BasicTests).pdf'
cp    ${LibraryDirectory}/Documents/ModelDocs/'md13_5_v1(Validation_Deposition).pdf'       ${NameDirectory}/ModelDocs/'md13_5_v1(Validation_Deposition).pdf'
cp    ${LibraryDirectory}/Documents/ModelDocs/'md13_6_v1(Validation_HighResUM).pdf'        ${NameDirectory}/ModelDocs/'md13_6_v1(Validation_HighResUM).pdf'
cp    ${LibraryDirectory}/Documents/ModelDocs/'md13_7_v1(Validation_PUMA).pdf'             ${NameDirectory}/ModelDocs/'md13_7_v1(Validation_PUMA).pdf'
cp    ${LibraryDirectory}/Documents/ModelDocs/'md13_8_v1(Validation_PUMA).pdf'             ${NameDirectory}/ModelDocs/'md13_8_v1(Validation_PUMA).pdf'
cp    ${LibraryDirectory}/Documents/ModelDocs/'md13_9_v1(Validation_UniformField).pdf'     ${NameDirectory}/ModelDocs/'md13_9_v1(Validation_UniformField).pdf'
cp    ${LibraryDirectory}/Documents/ModelDocs/'md13_10_v1(Validation_Nottingham).pdf'      ${NameDirectory}/ModelDocs/'md13_10_v1(Validation_Nottingham).pdf'
cp    ${LibraryDirectory}/Documents/ModelDocs/'md13_11_v1(Validation_O3LandUseDryDep).pdf' ${NameDirectory}/ModelDocs/'md13_11_v1(Validation_O3LandUseDryDep).pdf'

cp    ${LibraryDirectory}/Documents/ModelDocs/'md14_1_v1(NAMEPorting).pdf'                 ${NameDirectory}/ModelDocs/'md14_1_v1(NAMEPorting).pdf'

cp -R ${LibraryDirectory}/Documents/ModelDocs/'md15_1_v2(IntroductionForUsers)'            ${NameDirectory}/ModelDocs/'md15_1_v2(IntroductionForUsers)'
#cp    ${LibraryDirectory}/Documents/ModelDocs/'md15_2_v1(IntroductionForDevelopers).ppt'   ${NameDirectory}/ModelDocs/'md15_2_v1(IntroductionForDevelopers).ppt'
cp    ${LibraryDirectory}/Documents/ModelDocs/'md15_3_v1(ComputerRequirements).pdf'        ${NameDirectory}/ModelDocs/'md15_3_v1(ComputerRequirements).pdf'
cp    ${LibraryDirectory}/Documents/ModelDocs/'md15_4_v2(Licensing).pdf'                   ${NameDirectory}/ModelDocs/'md15_4_v2(Licensing).pdf'
cp    ${LibraryDirectory}/Documents/ModelDocs/'md15_5_v2(List_of_papers).pdf'              ${NameDirectory}/ModelDocs/'md15_5_v2(List_of_papers).pdf'

cp    ${LibraryDirectory}/Documents/ModelDocs/'md17_1_v1(MetData_GlobalCutoutDomains).pdf' ${NameDirectory}/ModelDocs/'md17_1_v1(MetData_GlobalCutoutDomains).pdf'
cp    ${LibraryDirectory}/Documents/ModelDocs/'md17_2_v1(Met_Data).pdf'                    ${NameDirectory}/ModelDocs/'md17_2_v1(Met_Data).pdf'
cp    ${LibraryDirectory}/Documents/ModelDocs/'md18_1_v1(Parallelisation).pdf'             ${NameDirectory}/ModelDocs/'md18_1_v1(Parallelisation).pdf'

#
# Write protect the folder containing the external-users version of NAME
#

chmod a-w ${NameDirectory}

exit 0
