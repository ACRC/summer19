/*----------------------------------------------------------------------------*/
/*  Number to string: C routines.                                             */
/*  These are wrapped with Fortran interfaces in module NumberToStringModule. */
/*----------------------------------------------------------------------------*/

#include "stdio.h"
#include "stdlib.h"
#include "string.h"

/*----------------------------------------------------------------------------*/
/*                                                                            */
/*----------------------------------------------------------------------------*/

void c_float_to_string(char * string,   float input_number, 
                       int field_width, char * format_string)
{

  snprintf(string, (size_t) field_width, format_string, input_number);

}

/*----------------------------------------------------------------------------*/
/*                                                                            */
/*----------------------------------------------------------------------------*/

void c_double_to_string(char * string,   double input_number, 
                        int field_width, char * format_string)
{

  snprintf(string, (size_t) field_width, format_string, input_number);
}

/*----------------------------------------------------------------------------*/
/*                                                                            */
/*----------------------------------------------------------------------------*/

void c_integer_to_string(char * string,   int input_number, 
                         int field_width, char * format_string)
{

  snprintf(string, (size_t) field_width, format_string, input_number);

}

/*----------------------------------------------------------------------------*/
/*                                                                            */
/*----------------------------------------------------------------------------*/


int c_string_to_integer(char * string)
{

  int output_number = atoi(string);   
  return (output_number);

}


